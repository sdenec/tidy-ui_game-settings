# FVTT UII - Game Settings
A module to make the game settings menu a bit mor comfortale to use.
A solo module from the upcoming FVTT UII module.

The buttons in the Settings Sidebar are arranged to be a little less confusind and are grouped by function.

All Input fields, and buttons are better aligned. Over all the element spacing makes reading and navigating more comfortable.

Now Module Settings in the Settings Tab start collapse and are expandable so you don't have to scroll thorugh endless checkboxes to find the one module you want to set up.

You now can click the Option section you want to set instead of klicking the tiny checkbox.

## Installation
See https://github.com/foundry-vtt-community/wiki/wiki/Modules#installing-modules. Open the Add-on Modules tab in the Configuration and Setup dialog. Click Install Module, paste https://raw.githubusercontent.com/sdenec/fvtt-uii_game-settings/master/module.json in as the Manifest URL, then click Install.

## Preview
![Sidebar](/preview/sidebar.jpg)

![Module Management](/preview/module-management.jpg)

![Settings - Core](/preview/core.jpg)

![Settings - System](/preview/system.jpg)

![Settings - Modules (compressed)](/preview/mod_compressed.jpg)

![Settings - Modules (expanded)](/preview/mod-expanded.jpg)
