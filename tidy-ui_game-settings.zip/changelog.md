*0.1.20*

- Added spanish translation. Thanks to José E. Lozano

*0.1.19*

- Added language support