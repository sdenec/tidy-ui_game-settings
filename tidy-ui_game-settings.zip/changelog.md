# Changelog

## 0.1.24

- compatibility version update
- css fix for very long module titles
- export as text and json files also list inactive modules
- ability to export JSON files to save active module list
- ability to import stored JSON list to set active module list
- legacy option to paste old text format for module list

## 0.1.23

- spanish translation update
- fixed scroll position for module settings searchbar
- fixed search results in module settings search

## 0.1.22

- taiwanese translation added
- css adjustments for buttons

## 0.1.21

- css adjustments for more compact module manager

## 0.1.20

- Added spanish translation. Thanks to José E. Lozano

## 0.1.19

- Added language support
