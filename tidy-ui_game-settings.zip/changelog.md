# Changelog

## 0.1.22

- taiwanese translation added
- css adjustments for buttons

## 0.1.21

- css adjustments for more compact module manager

## 0.1.20

- Added spanish translation. Thanks to José E. Lozano

## 0.1.19

- Added language support
